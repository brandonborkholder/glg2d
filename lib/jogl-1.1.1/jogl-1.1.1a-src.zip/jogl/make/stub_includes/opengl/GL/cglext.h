#ifndef __cglext_h_
#define __cglext_h_

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

